<?php   
    session_start();
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit();
    }

    // Include your database connection
    include 'config.php';

    $user_id = $_SESSION['user_id'];

    // Fetch user details
    $sql = "SELECT name FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($user_name);
    $stmt->fetch();
    $stmt->close();

    // Fetch AI-recommended appointment slots from Flask API
    $url = "http://127.0.0.1:5000/get_smart_slots";
    $response = file_get_contents($url);
    $data = json_decode($response, true);
    
    if (!$data || !isset($data['suggested_slots'])) {
        die("<p>Error fetching time slots. Please try again later.</p>");
    }
    
    $recommended_slots = $data['suggested_slots'];
    
    if (empty($recommended_slots)) {;
    } else {
        foreach ($recommended_slots as $slot) {
            $date = isset($slot['date']) ? $slot['date'] : 'N/A';
            $start_time = isset($slot['start_time']) ? $slot['start_time'] : 'N/A';
            $end_time = isset($slot['end_time']) ? $slot['end_time'] : 'N/A';
            }
    }

            // Fetch counselor ID and check if the slot is available in the database
            $sql = "SELECT id, counselor_id FROM availability 
                    WHERE date = ? AND start_time = ? AND end_time = ? 
                    AND status = 'available' AND request_status = 'available'";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $date, $start_time, $end_time);
            $stmt->execute();
            $stmt->bind_result($slot_id, $counselor_id);

            while ($stmt->fetch()) {
                $available_slots[] = [
                    'id' => $slot_id,
                    'counselor_id' => $counselor_id,
                    'date' => $date,
                    'start_time' => $start_time,
                    'end_time' => $end_time
                ];
            }
            $stmt->close();

    // Prevent cached access
    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Pragma: no-cache");

    // Handle booking process
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['slot_id'])) {
        $slot_id = $_POST['slot_id'];

        // Fetch the slot details
        $check_sql = "SELECT counselor_id, date, start_time, end_time, status FROM availability WHERE id = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("i", $slot_id);
        $check_stmt->execute();
        $check_stmt->bind_result($counselor_id, $date, $start_time, $end_time, $status);
        $check_stmt->fetch();
        $check_stmt->close();

        if ($status === 'booked') {
            echo "<script>alert('This slot is already booked!');</script>";
        } else {
            // Insert into appointment table and mark status as 'Scheduled'
            $insert_sql = "INSERT INTO appointments (counselor_id, student_id, date, start_time, end_time, status) 
                        VALUES (?, ?, ?, ?, ?, 'scheduled')";
            $insert_stmt = $conn->prepare($insert_sql);
            $insert_stmt->bind_param("iisss", $counselor_id, $user_id, $date, $start_time, $end_time);

            if ($insert_stmt->execute()) {
                // Update availability table to mark slot as booked
                $update_sql = "UPDATE availability SET status = 'booked' WHERE id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("i", $slot_id);
                $update_stmt->execute();
                $update_stmt->close();

                echo "<script>alert('Your appointment has been booked successfully!'); window.location.href='view_student.php';</script>";
            } else {
                echo "<script>alert('Error booking the appointment. Please try again later.');</script>";
            }
            $insert_stmt->close();
        }
    }
    $all_slots = [];

    $sql = "SELECT a.id, u.name AS counselor_name, a.date, a.start_time, a.end_time 
    FROM availability a
    JOIN users u ON a.counselor_id = u.id
    WHERE a.status = 'available'";


$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->execute();
    $stmt->bind_result($slot_id, $counselor_name, $date, $start_time, $end_time);
    
    while ($stmt->fetch()) {
        $all_slots[] = [
            'id' => $slot_id,
            'counselor_name' => $counselor_name,
            'date' => $date,
            'start_time' => $start_time,
            'end_time' => $end_time
        ];
    }
    $stmt->close();
} else {
    echo "<p>Error fetching available slots.</p>";
}

    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>MapÃºaCARE - Book Appointment</title>
        <style>
            body{          font-family: Arial, sans-serif;
                    margin: 0;
                    padding: 0;
                    background-color: #f8f8f8;
                }
                .header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 15px 40px;
                    border-bottom: 2px solid black;
                    background: white;
                }
                .logo img {
                    height: auto;
                    width: auto;
                }
                .nav-buttons {
                    display: flex;
                    gap: 20px;
                }
                .nav-buttons button {
                    padding: 10px 40px;
                    border: none;
                    cursor: pointer;
                    font-size: 16px;
                    transition: background 0.3s ease;
                }
                .home-btn {
                    background: #F7D774;
                    margin-left: 100px;
                }
                .calendar-btn, .contact-btn {
                    background: #ccc;
                    margin-left: 100px;
                }
                .contact-btn {
                    margin-right: 100px;
                }
                .nav-buttons button:hover {
                    background: #b3b3b3;
                }
                .sidebar {
                    width: 330px;
                    background: white;
                    padding: 20px;
                    left: 0;
                    top: 0;
                    display: flex;
                    flex-direction: column;
                    border-right: 2px solid black;
                }
                h2 {
                    margin-left: 20px;
                    font-size: 30px;
                    margin-top: 0px;
                }
                .book-btn {
                    margin-top: 70px;
                    background: rgb(236, 31, 31);
                    margin-bottom: 20px;
                }
                .appoint-btn {
                    margin-bottom: 120px;
                    background: #ccc;
                }
                .view-btn {
                    background: #ccc;
                    margin-bottom: 90px;
                }
                .navone-buttons {
                    display: flex;
                    gap: 20px;
                }
                .navone-buttons button {
                    padding: 25px 40px;
                    border: none;
                    cursor: pointer;
                    font-size: 16px;
                    transition: background 0.3s ease;
                }
                .navone-buttons button:hover {
                    background: rgb(236, 31, 31);
                }
                .logout-container { 
                    display: flex;
                    align-items: center;
                    padding-left: 5px;
                    background-color: #F7D774;
                    height: 65px;
                    border-radius: 20px;
                    margin-top: 30px;
                }
                .username {
                    font-size: 18px;
                    font-weight: bold;
                    margin-bottom: 3px;
                    margin-left: 20px;
                }
                .logout-btn {
                    width: 40px;
                    cursor: pointer;
                    margin-left: 150px;
                    margin-bottom: 3px;
                }
                .menu-btn {
                    width: 40px;
                    margin-left: 300px;
                    cursor: pointer;
                }
                .table-container {
                    margin: 20px auto;
                    width: 80%;
                    background: white;
                    padding: 20px;
                    border-radius: 10px;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                }
                th, td {
                    padding: 10px;
                    border: 1px solid black;
                    text-align: left;
                }
                th {
                    background: #f2f2f2;
                }
                .book-btn-table {
                    padding: 5px 10px;
                    background: rgb(236, 31, 31);
                    color: white;
                    border: none;
                    cursor: pointer;
                }
                .book-btn-table:hover {
                    background: #b30000;
                }
                .container {
                    display: flex;
                    flex-direction: row;
                    width: 100%;
                }
                .appointments {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 20px;
                    justify-content: center;
                }

                .appointment-card {
                    background: white;
                    padding: 20px;
                    border-radius: 10px;
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.54);
                    text-align: center;
                    width: 250px;
                }

                .appointment-card h3 {
                    margin: 0;
                    font-size: 20px;
                    color: #333;
                }

                .appointment-card p {
                    font-size: 16px;
                    color: #666;
                }

                .book-btn-table {
                    padding: 10px 15px;
                    background: rgb(236, 31, 31);
                    color: white;
                    border: none;
                    cursor: pointer;
                    border-radius: 5px;
                    margin-top: 10px;
                }

                .book-btn-table:hover {
                    background: #b30000;
                }
                .show-all-btn {
            padding: 10px 20px;
            background:rgb(175, 168, 76);
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            margin: 10px;
        }
        .show-all-btn:hover {
            background:rgb(158, 160, 69);
        }
        </style>
    </head>
    <body>

        <div class="header">
            <div class="logo">
                <img src="images/logo.png" alt="MapÃºaCARE" onclick="location.href='student_dashboard.php'">
            </div>
            <div class="nav-buttons">
                <button class="home-btn" onclick="location.href='student_dashboard.php'">Home</button>
                <button class="calendar-btn" onclick="location.href='calendar_student.php'">Calendar</button>
                <button class="contact-btn" onclick="location.href='contactus.php'">Contact Us</button>
            </div>
        </div>

        <div class="container">
            <div class="navone-buttons">
                <div class="sidebar">
                    <img src="images/hamburger-menu.svg" class="menu-btn" alt="menu">
                    <h2>Home</h2>
                    <button class="book-btn" onclick="location.href='book_appointment.php'">Book Appointment</button>
                    <button class="appoint-btn" onclick="location.href='view_student.php'">View Appointment</button>
                    <div class="logout-container">
                <span class="username"><?php echo htmlspecialchars($user_name); ?></span>
                <img src="images/log-out.svg" class="logout-btn" alt="logout" onclick="location.href='logout.php'">
            </div>
                </div>
            </div>

            <div class="table-container">
    <h2>AI-Suggested Appointments</h2>

    <!-- Buttons for Morning or Afternoon preference -->
    <div style="text-align: center; margin-bottom: 20px;">
        <button onclick="filterSlots('morning')" style="padding: 10px 20px; margin-right: 10px; background: #FFD700; border: none; cursor: pointer;">Morning</button>
        <button onclick="filterSlots('afternoon')" style="padding: 10px 20px; background: #FFA500; border: none; cursor: pointer;">Afternoon</button>
    </div>

    <div class="appointments" id="appointments-container">
        <?php if (!empty($available_slots)) { ?>
            <?php foreach ($available_slots as $slot) { ?>
                <div class="appointment-card" data-time="<?php echo (intval(substr($slot['start_time'], 0, 2)) < 12) ? 'morning' : 'afternoon'; ?>">
                    <h3><?php echo htmlspecialchars($slot['date']); ?></h3>
                    <p><strong>Time:</strong> <?php echo htmlspecialchars($slot['start_time']) . " - " . htmlspecialchars($slot['end_time']); ?></p>
                    <form method="POST" action="book_appointment.php">
                        <input type="hidden" name="slot_id" value="<?php echo $slot['id']; ?>">
                        <button type="submit" class="book-btn-table">Book Now</button>
                    </form>
                </div>
            <?php } ?>
        <?php } else { ?>
            <p>No AI-recommended slots available at the moment.</p>
        <?php } ?>
    </div>
</div>
<button id="toggle-btn">Show All Available Dates</button>
<div id="available-slots" style="display: none;">
    <table>
        <tr>
            <th>Counselor</th>
            <th>Date</th>
            <th>Start Time</th>
            <th>End Time</th>
        </tr>
        <?php foreach ($all_slots as $slot): ?>
            <tr>
                <td><?php echo htmlspecialchars($slot['counselor_name']); ?></td>
                <td><?php echo htmlspecialchars($slot['date']); ?></td>
                <td><?php echo htmlspecialchars($slot['start_time']); ?></td>
                <td><?php echo htmlspecialchars($slot['end_time']); ?></td>
                <td>
                    <form method="POST">
                        <input type="hidden" name="slot_id" value="<?= htmlspecialchars($slot['id']) ?>">
                        <button type="submit" class="book-btn-table">Book</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>
</div>  

</body>
</html>

<script>
function filterSlots(preference) {
    let slots = document.querySelectorAll('.appointment-card');
    let buttons = document.querySelectorAll('button');
    
    buttons.forEach(btn => btn.style.opacity = "1"); // Reset all buttons
    event.target.style.opacity = "0.6"; // Highlight selected button

    slots.forEach(slot => {
        if (slot.getAttribute('data-time') === preference || preference === 'all') {
            slot.style.display = "block";
        } else {
            slot.style.display = "none";
        }
    });
}
document.getElementById('toggle-btn').addEventListener('click', function() {
    var slotDiv = document.getElementById('available-slots');
    if (slotDiv.style.display === "none") {
        slotDiv.style.display = "block";
        this.textContent = "Hide Available Dates";
    } else {
        slotDiv.style.display = "none";
        this.textContent = "Show All Available Dates";
    }
});

</script>

    </body>
    </html>