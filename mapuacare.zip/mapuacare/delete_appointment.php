<?php
session_start();
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['appointment_id'])) {
    $appointment_id = intval($_POST['appointment_id']);

    // Delete appointment from database
    $sql = "DELETE FROM appointments WHERE id = ?";
    
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $appointment_id);
        if ($stmt->execute()) {
            echo "Appointment deleted successfully.";
        } else {
            echo "Error deleting appointment.";
        }
        $stmt->close();
    } else {
        echo "Database error.";
    }
}
?>
