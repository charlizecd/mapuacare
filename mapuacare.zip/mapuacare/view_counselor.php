<?php   
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'config.php';

$user_id = $_SESSION['user_id'];

// Fetch user details
$user_name = "Unknown";
if ($stmt = $conn->prepare("SELECT name FROM users WHERE id = ?")) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $user_name = $row['name'];
    }
    $stmt->close();
}

// Fetch user's appointments
$appointments = [];
$sql = "SELECT a.id, a.date, a.start_time, a.end_time, s.name AS student_name, a.status
        FROM appointments a
        JOIN users s ON a.student_id = s.id
        WHERE a.counselor_id = ?";

if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $appointments[] = $row;
    }
    $stmt->close();
}

// Handle appointment updates
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['appointment_id']) && isset($_POST['action'])) {
    $appointment_id = $_POST['appointment_id'];
    $action = $_POST['action'];

    if ($action === "complete") {
        $update_sql = "UPDATE appointments SET status = 'completed' WHERE id = ?";
    } elseif ($action === "cancel") {
        $query = "SELECT counselor_id, date, start_time, end_time FROM appointments WHERE id = ?";
        if ($stmt = $conn->prepare($query)) {
            $stmt->bind_param("i", $appointment_id);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($appointment = $result->fetch_assoc()) {
                $counselor_id = $appointment['counselor_id'];
                $date = $appointment['date'];
                $start_time = $appointment['start_time'];
                $end_time = $appointment['end_time'];

                $delete_sql = "DELETE FROM availability WHERE counselor_id = ? AND date = ? AND start_time = ? AND end_time = ?";
                if ($stmt = $conn->prepare($delete_sql)) {
                    $stmt->bind_param("isss", $counselor_id, $date, $start_time, $end_time);
                    $stmt->execute();
                    $stmt->close();
                }
            }
        }
        $update_sql = "UPDATE appointments SET status = 'canceled' WHERE id = ?";
    } else {
        exit("Invalid action.");
    }

    if ($stmt = $conn->prepare($update_sql)) {
        $stmt->bind_param("i", $appointment_id);
        $stmt->execute();
        $stmt->close();
    }

    header("Location: view_counselor.php"); 
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MapúaCARE - View Appointments</title>
    <style>
        /* Global Styles */
body {
    font-family: Arial, sans-serif;
    background-color: #f8f8f8;
    margin: 0;
    padding: 0;
}

/* Header Section */
.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 40px;
    background: white;
    border-bottom: 2px solid black;
}

.logo img {
    height: auto;
    width: auto;
    cursor: pointer;
}

/* Navigation Buttons */
.nav-buttons {
    display: flex;
    gap: 20px;
}

.nav-buttons button {
    padding: 10px 40px;
    border: none;
    cursor: pointer;
    font-size: 16px;
    transition: background 0.3s ease;
}

.home-btn {
    background: #F7D774;
    margin-left: 100px;
}

.calendar-btn, .contact-btn {
    background: #ccc;
    margin-left: 100px;
}

.contact-btn {
    margin-right: 115px;
}

.nav-buttons button:hover {
    background: #b3b3b3;
}

/* Sidebar */
.sidebar {
    width: 330px;
    background: white;
    padding: 20px;
    left: 0;
    top: 0;
    display: flex;
    flex-direction: column;
    border-right: 2px solid black;
}

h2 {
    margin-left: 20px;
    font-size: 30px;
    margin-top: 0px;
}

.navone-buttons {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.navone-buttons button {
    padding: 25px 40px;
    border: none;
    cursor: pointer;
    font-size: 16px;
    transition: background 0.3s ease;
}

.add-btn {
    margin-top: 70px;
    background: #ccc;
    margin-bottom: 20px;
}

.view-btn {
    background: #ccc;
    margin-bottom: 20px;
}

.appoint-btn {
    margin-bottom: 70px;
    background: rgb(241, 63, 63);
}

.navone-buttons button:hover {
    background: rgb(236, 31, 31);
}

/* Logout Section */
.logout-container { 
    display: flex;
    align-items: center;
    padding-left: 5px;
    background-color: #F7D774;
    height: 65px;
    border-radius: 20px;
}

.username {
    font-size: 18px;
    font-weight: bold;
    margin-left: 20px;
}

.logout-btn {
    width: 40px;
    cursor: pointer;
    margin-left: 150px;
}

.menu-btn {
    width: 40px;
    margin-left: 300px;
    cursor: pointer;
}

/* Appointments Section */
.appointments-container {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: center;
    padding: 20px;
}

.appointment-card {
    background-color: white;
    border-radius: 10px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
    padding: 15px;
    width: 280px;
    text-align: center;
    position: relative;
    border-left: 5px solid #ffcc00;
}

.appointment-card h3 {
    margin: 5px 0;
    font-size: 18px;
    color: #333;
}

.appointment-card p {
    font-size: 14px;
    color: #666;
    margin: 5px 0;
}

/* Appointment Status */
.status {
    padding: 6px 12px;
    border-radius: 8px;
    text-transform: capitalize;
    font-weight: bold;
    display: inline-block;
}

.status.completed {
    background-color: #4CAF50;
    color: white;
}

.status.pending {
    background-color: #FFC107;
    color: black;
}

.status.canceled {
    background-color: #F44336;
    color: white;
}

/* Action Buttons */
.button-container {
    margin-top: 10px;
}

.complete-btn, .cancel-btn {
    border: none;
    padding: 8px 12px;
    cursor: pointer;
    font-size: 14px;
    border-radius: 5px;
    margin: 5px;
}

.complete-btn {
    background-color: #4CAF50;
    color: white;
}

.cancel-btn {
    background-color: #F44336;
    color: white;
}
.container-side {
    display: flex;
    flex-direction: row;
    width: 100%;
    align-items: flex-start; /* Ensures they align at the top */
}

    </style>
</head>
<body>

    <!-- Header Section -->
    <div class="header">
        <div class="logo">
            <img src="images/logo.png" alt="MapúaCARE" onclick="location.href='counselor_dashboard.php'">
        </div>
        <div class="nav-buttons">
            <button class="home-btn" onclick="location.href='counselor_dashboard.php'">Home</button>
            <button class="calendar-btn" onclick="location.href='calendar_counselor.php'">Calendar</button>
            <button class="contact-btn" onclick="location.href='contactus.php'">Contact Us</button>
        </div>
    </div>

    <div class="container-side">
    <!-- **Sidebar (Added and Fully Integrated)** -->
    <div class="navone-buttons">
        <div class="sidebar">
            <img src="images/hamburger-menu.svg" class="menu-btn" alt="menu">
            <h2>Appointments</h2>
            <button class="add-btn" onclick="location.href='add_availability.php'">Add Available Dates</button>
            <button class="view-btn" onclick="location.href='view_available_date.php'">View Available Dates</button>
            <button class="appoint-btn" onclick="location.href='view_counselor.php'">View Appointment</button>
            <div class="logout-container">
                <span class="username"><?php echo htmlspecialchars($user_name); ?></span>
                <img class="logout-btn" src="images/log-out.svg" alt="logout" onclick="window.location.href='logout.php'">
            </div>
        </div>
    </div>

    <!-- Appointments Section -->
    <div class="appointments-container">
        <?php if (!empty($appointments)): ?>
            <?php foreach ($appointments as $appointment): ?>
                <div class="appointment-card">
                    <h3><?php echo htmlspecialchars($appointment['student_name']); ?></h3>
                    <p><strong>Date:</strong> <?php echo htmlspecialchars($appointment['date']); ?></p>
                    <p><strong>Time:</strong> <?php echo htmlspecialchars($appointment['start_time']) . " - " . htmlspecialchars($appointment['end_time']); ?></p>
                    <p><strong>Status:</strong> 
                        <span class="status <?php echo strtolower($appointment['status']); ?>">
                            <?php echo ucfirst(htmlspecialchars($appointment['status'])); ?>
                        </span>
                    </p>
                    <div class="button-container">
                        <?php if ($appointment['status'] !== 'completed' && $appointment['status'] !== 'canceled'): ?>
                            <form method="post" style="display:inline;">
                                <input type="hidden" name="appointment_id" value="<?php echo $appointment['id']; ?>">
                                <input type="hidden" name="action" value="complete">
                                <button type="submit" class="complete-btn">Complete</button>
                            </form>
                            <form method="post" style="display:inline;">
                                <input type="hidden" name="appointment_id" value="<?php echo $appointment['id']; ?>">
                                <input type="hidden" name="action" value="cancel">
                                <button type="submit" class="cancel-btn">Cancel</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p style="text-align:center;">No appointments found.</p>
        <?php endif; ?>
    </div>
    </div>

</body>
</html>
