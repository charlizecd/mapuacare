<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Include your database connection
include 'config.php';

// Fetch user details
$user_id = $_SESSION['user_id'];
$sql = "SELECT name FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($user_name);
$stmt->fetch();
$stmt->close();

// Prevent cached access
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Handle Delete user
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $delete_sql = "DELETE FROM users WHERE id = ?";
    $delete_stmt = $conn->prepare($delete_sql);
    $delete_stmt->bind_param("i", $delete_id);
    $delete_stmt->execute();
    $delete_stmt->close();
    header("Location: admin_dashboard.php"); // Refresh page after deletion
}

// Handle Add new user
if (isset($_POST['add_user'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $mapua_id_number = $_POST['mapua_id_number']; // NEW FIELD
    $role_id = $_POST['role_id'];

    $add_sql = "INSERT INTO users (name, email, password, mapua_id_number, role) VALUES (?, ?, ?, ?, ?)";
    $add_stmt = $conn->prepare($add_sql);
    $add_stmt->bind_param("ssssi", $name, $email, $password, $mapua_id_number, $role_id);
    $add_stmt->execute();
    $add_stmt->close();
    
    header("Location: admin_dashboard.php"); // Refresh page after adding new user
}

// Fetch all users for display in the table
$fetch_sql = "SELECT id, name, email, role, mapua_id_number FROM users";
$fetch_result = $conn->query($fetch_sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MapúaCARE - Admin Dashboard</title>
    <style>
        /* Styles for the table and buttons */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f8f8;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 40px;
            border-bottom: 2px solid black;
            background: white;
        }
        .logo img {
            height: auto;
            width: auto;
        }
        .nav-buttons {
            display: flex;
            gap: 20px;
        }
        .nav-buttons button {
            padding: 10px 40px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s ease;
        }
        .home-btn {
            background: #F7D774;
            margin-left: 100px;
        }
        .calendar-btn, .contact-btn {
            background: #ccc;
            margin-left: 100px;
        }
        .contact-btn {
            margin-right: 115px;
        }
        .nav-buttons button:hover {
            background: #b3b3b3;
        }
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: #f7d774;
        }
        .action-btns a {
            margin-right: 10px;
            text-decoration: none;
            padding: 5px 10px;
            background-color: #f7d774;
            border-radius: 5px;
            color: black;
        }
        .action-btns a:hover {
            background-color: #b3b3b3;
        }
        .logout-container { 
    display: flex;
    align-items: center;
    padding-left: 5px; /* Adjust for alignment */
    background-color: #F7D774;
    height: 65px;
    border-radius: 20px;
    width: 400px;
    margin-left: 500px;
    margin-top: 150px;
}

.username {
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 3px;
    margin-left: 20px;
}

.logout-btn {
    width: 40px;
    cursor: pointer;
    margin-left: 150px;
    margin-bottom: 3px;
}
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">
            <img src="images/logo.png" alt="MapúaCARE" onclick="location.href='admin_dashboard.php'">
        </div>
        <div class="nav-buttons">
            <button class="home-btn" onclick="location.href='admin_dashboard.php'">Home</button>
            <button class="calendar-btn" onclick="location.href='calendar_admin.php'">Calendar</button>
            <button class="contact-btn" onclick="location.href='contactus.php'">Contact Us</button>
        </div>
    </div>

    <h2 style="text-align:center; margin-top: 20px;">User Management</h2>

    <!-- Add New User Form -->
    <form method="POST" style="text-align: center; margin: 20px;">
    <input type="text" name="name" placeholder="Name" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Password" required>
    <input type="text" name="mapua_id_number" placeholder="Mapua ID Number" required>  <!-- NEW FIELD -->
    <select name="role_id" required>
        <option value="1">Student</option>
        <option value="2">Counselor</option>
        <option value="3">Admin</option>
    </select>
    <button type="submit" name="add_user">Add User</button>
</form>


    <!-- Users Table -->
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Mapua ID</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($fetch_result->num_rows > 0) {
                while ($row = $fetch_result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . $row['name'] . "</td>";
                    echo "<td>" . $row['email'] . "</td>";
                    echo "<td>" . ($row['role'] == 3 ? "Admin" : ($row['role'] == 2 ? "Counselor" : "Student")) . "</td>";
                    echo "<td>" . $row['mapua_id_number'] . "</td>";
                    echo "<td class='action-btns'>";
                    echo "<a href='edit_admin.php?id=" . $row['id'] . "'>Edit</a>";
                    echo "<a href='admin_dashboard.php?delete_id=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this user?\")'>Delete</a>";
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No users found</td></tr>";
            }
            ?>
        </tbody>
    </table>
    <div class="logout-container">
    <span class="username"><?php echo htmlspecialchars($user_name); ?></span>
    <img src="images/log-out.svg" class="logout-btn" alt="logout" onclick="location.href='logout.php'">
</div>
</body>
</html>



