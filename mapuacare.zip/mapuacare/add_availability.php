<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'config.php';

$user_id = $_SESSION['user_id'];

// Fetch user details
$user_name = "Unknown";
if ($stmt = $conn->prepare("SELECT name FROM users WHERE id = ?")) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $user_name = $row['name'];
    }
    $stmt->close();
}
// Handle availability submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $date = $_POST['date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];

    if (strtotime($end_time) <= strtotime($start_time)) {
        $message = "<p style='color: red;'>End time must be after start time.</p>";
    } else {
        // Check if the same date, start time, and end time already exist
        if ($stmt = $conn->prepare("SELECT COUNT(*) FROM availability WHERE counselor_id = ? AND date = ? AND start_time = ? AND end_time = ?")) {
            $stmt->bind_param("isss", $user_id, $date, $start_time, $end_time);
            $stmt->execute();
            $stmt->bind_result($count);
            $stmt->fetch();
            $stmt->close();

            if ($count > 0) {
                $message = "<p style='color: red;'>You cannot add the same start and end time on the same date.</p>";
            } else {
                // Proceed with insertion
                if ($stmt = $conn->prepare("INSERT INTO availability (counselor_id, date, start_time, end_time, status) VALUES (?, ?, ?, ?, 'available')")) {
                    $stmt->bind_param("isss", $user_id, $date, $start_time, $end_time);
                    if ($stmt->execute()) {
                        $message = "<p style='color: green;'>Availability added successfully.</p>";
                    } else {
                        $message = "<p style='color: red;'>Error adding availability.</p>";
                    }
                    $stmt->close();
                } else {
                    $message = "<p style='color: red;'>Database error: " . $conn->error . "</p>";
                }
            }
        } else {
            $message = "<p style='color: red;'>Database error: " . $conn->error . "</p>";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MapúaCARE - Add Availability</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f8f8;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 40px;
            border-bottom: 2px solid black;
            background: white;
        }
        .logo img {
            height: auto;
            width: auto;
        }
        .nav-buttons {
            display: flex;
            gap: 20px;
        }
        .nav-buttons button {
            padding: 10px 40px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s ease;
        }
        .home-btn {
            background: #F7D774;
            margin-left: 100px;
        }
        .calendar-btn, .contact-btn {
            background: #ccc;
            margin-left: 100px;
        }
        .contact-btn {
            margin-right: 115px;
        }
        .nav-buttons button:hover {
            background: #b3b3b3;
        }
        .sidebar {
            width: 330px;
            background: white;
            padding: 20px;
            left: 0;
            top: 0;
            display: flex;
            flex-direction: column;
            border-right: 2px solid black;
        }
        h2 {
            margin-left: 20px;
            font-size: 30px;
            margin-top: 0px;
        }
        .add-btn {
            margin-top: 70px;
            background: rgb(241, 63, 63);
            margin-bottom: 20px;
        }
        .appoint-btn {
            margin-bottom: 70px;
            background: #ccc;
        }
        .view-btn {
            background: #ccc;
            margin-bottom: 20px;
        }
        .navone-buttons {
            display: flex;
            gap: 20px;
        }
        .navone-buttons button {
            padding: 25px 40px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s ease;
        }
        .navone-buttons button:hover {
            background: rgb(236, 31, 31);
        }
        .logout-container { 
            display: flex;
            align-items: center;
            padding-left: 5px;
            background-color: #F7D774;
            height: 65px;
            border-radius: 20px;
        }
        .username {
            font-size: 18px;
            font-weight: bold;
            margin-left: 20px;
        }
        .logout-btn {
            width: 40px;
            cursor: pointer;
            margin-left: 150px;
        }
        .menu-btn {
            width: 40px;
            margin-left: 300px;
            cursor: pointer;
        }

        /* Card container styling */
        .form-container {
            flex-grow: 1;
            background-color: #ffffff;
            padding: 30px;
            margin: 50px auto; /* Centering the form with margin */
            border-radius: 15px; /* Rounded corners for the card effect */
            box-shadow: 0 10px 20px rgba(15, 14, 14, 0.6); /* Soft shadow for depth */
            max-width: 500px; /* Limiting the width for a card effect */
            box-sizing: border-box;
            border: 1px solid #ddd; /* Subtle border to define the card */
        }

        /* Form title */
        .form-container h3 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
            color: #333;
            text-align: center;
            border-bottom: 2px solid #ddd; /* Subtle divider under title */
            padding-bottom: 10px;
        }

        /* Form labels */
        form label {
            font-size: 16px;
            font-weight: 600;
            color: #555;
            margin-bottom: 8px;
            display: block;
        }

        /* Form input fields */
        form input {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;  /* Rounded input fields */
            font-size: 16px;
            transition: border-color 0.3s ease;
        }

        /* Focus state for input fields */
        form input:focus {
            border-color: #4CAF50;
            outline: none;
        }

        /* Submit button styling */
        .submit-btn {
            background-color:rgb(230, 66, 66);
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s ease;
        }

        /* Submit button hover effect */
        .submit-btn:hover {
            background-color:rgb(148, 160, 149);
        }

        /* Message styling */
        .message {
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-size: 16px;
            color: #333;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .container{
            display: flex;
            flex-direction: row; /* Side by side */
            width: 100%;
        }
    </style>
</head>
<body>

    <div class="header">
        <div class="logo">
            <img src="images/logo.png" alt="MapúaCARE" onclick="location.href='counselor_dashboard.php'">
        </div>
        <div class="nav-buttons">
            <button class="home-btn" onclick="location.href='counselor_dashboard.php'">Home</button>
            <button class="calendar-btn" onclick="location.href='calendar_counselor.php'">Calendar</button>
            <button class="contact-btn" onclick="location.href='contactus.php'">Contact Us</button>
        </div>
    </div>

    <div class="container">
    <div class="navone-buttons">
        <div class="sidebar">
            <img src="images/hamburger-menu.svg" class="menu-btn" alt="menu">
            <h2>Home</h2>
            <button class="add-btn" onclick="location.href='add_availability.php'">Add Available Dates</button>
            <button class="view-btn" onclick="location.href='view_available_date.php'">View Available Dates</button>
            <button class="appoint-btn" onclick="location.href='view_counselor.php'">View Appointment</button>
            <div class="logout-container">
                <span class="username"><?php echo htmlspecialchars($user_name); ?></span>
                <img class="logout-btn" src="images/log-out.svg" alt="logout" onclick="window.location.href='logout.php'">
            </div>
        </div>
    </div>
    
    <div class="form-container">
        <h3>Add Available Date</h3>

        <?php if (isset($message)) { echo "<div class='message'>$message</div>"; } ?>

        <form method="POST">
            <label for="date">Date:</label>
            <input type="date" id="date" name="date" required>

            <label for="start_time">Start Time:</label>
            <input type="time" id="start_time" name="start_time" required>

            <label for="end_time">End Time:</label>
            <input type="time" id="end_time" name="end_time" required>

            <button type="submit" class="submit-btn">Save</button>
        </form>
    </div>
    </div>
</body>
</html>
