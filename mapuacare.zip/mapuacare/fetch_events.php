<?php
require_once 'config.php'; // Database connection

header('Content-Type: application/json');


// Fetch events using appointment_id from calendar_sync
$sql = "SELECT cs.id, a.date, a.start_time AS start, a.end_time AS end 
        FROM calendar_sync cs
        JOIN appointments a ON cs.appointment_id = a.id"; 

$result = $conn->query($sql);

$events = [];

while ($row = $result->fetch_assoc()) {
    $events[] = [
        'id' => $row['id'],
        'start' => $row['date'] . 'T' . $row['start'], // Combine date and time
        'end' => $row['date'] . 'T' . $row['end']
    ];
}

// Output JSON
echo json_encode($events);

$conn->close();
?>