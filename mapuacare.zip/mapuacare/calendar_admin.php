<?php   
session_start();
require_once 'config.php'; // Database connection

// Fetch user details
$user_id = $_SESSION['user_id'];
$sql = "SELECT name FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($user_name);
$stmt->fetch();
$stmt->close();

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MapúaCARE - Home</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.11.5/main.min.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.11.5/main.min.js"></script>

    <style>
         body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f8f8;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 40px;
            border-bottom: 2px solid black;
            background: white;
        }
        .logo img {
            height: auto;
            width: auto;
        }
        .nav-buttons {
            display: flex;
            gap: 20px;
        }
        .nav-buttons button {
            padding: 10px 40px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s ease;
        }
        .home-btn {
            background: #ccc;
            margin-left: 100px;
        }
        .calendar-btn {
            background: #F7D774;
            margin-left: 100px;
        }
        .contact-btn {
            margin-right: 115px;
            margin-left: 100px;
            background: #ccc;


        }
        .nav-buttons button:hover {
            background: #b3b3b3;
        }
        .sidebar {
    width: 330px;
    height: 600px; 
    background: #ffffff;
    padding: 30px 20px;
    display: flex;
    flex-direction: column;
    border-right: 2px solid black;
    box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

/* Center text and add spacing */
h2 {
    font-size: 28px;
    text-align: left;
    color: #333;
    margin-bottom: 100px;
    margin-left: 10px;
}

/* Button Styles */
.sidebar button {
    width: 100%;
    padding: 15px;
    font-size: 16px;
    border: none;
    cursor: pointer;
    transition: background 0.3s ease, transform 0.2s;
    margin: 10px 0 ; /* Add space between buttons */
    border-radius: 0px;
}

.book-btn {
    background: #ccc;
    color: #333;
    font-weight: bold;
}

.appoint-btn {
    background: #ccc;
    color: #333;
    font-weight: bold;
}

/* Hover Effects */
.sidebar button:hover {
    transform: scale(1.05);
    opacity: 0.9;
}

/* Menu Icon */
.menu-btn {
    width: 40px;
    margin-left: 290px;
    display: block;
    cursor: pointer;
}
        .logout-container { 
            display: flex;
            align-items: center;
            padding-left: 5px;
            background-color: #F7D774;
            height: 65px;
            border-radius: 20px;
            margin-top: 250px;

        }
        .username {
            font-size: 18px;
            font-weight: bold;
            margin-left: 20px;
        }
        .logout-btn {
            width: 40px;
            cursor: pointer;
            margin-left: 150px;
        }
        .content {
            margin-left: 320px;
            padding: 20px;
        }
        .calendar-container {
            width: 100%;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }
        .container{
            display: flex;
            flex-direction: row; /* Side by side */
            width: 100%;
        } 
        .calendar-map{
    width: 100%;
    height: 650px;
    border: none;

}
/* Change toolbar background */
.calendar-map .fc-toolbar {
    background-color: white; /* Dark background */
    color: black; /* Text color */
    border-radius: 5px;
}

/* Change navigation buttons (prev, next, today) */
.calendar-map .fc-button {
    background-color:rgba(246, 0, 0, 0.78) !important;
    border: none;
    border-radius: 5px;
}

/* Change hover effect */
.calendar-map .fc-button:hover {
    background-color:   rgba(18, 18, 19, 0.21) !important; 
}

/* Change active button (month, week, day) */
.calendar-map .fc-button-active {
    background-color:rgba(239, 171, 23, 0.98) !important;
    color: white !important;
}

/* Change title (March 2025) */
.calendar-map .fc-toolbar-title {
    font-size: 20px;
    font-weight: bold;
    color: #222; /* Change title color */
}

    </style>
</head>
<body>

    <div class="header">
        <div class="logo">
            <img src="images/logo.png" alt="MapúaCARE" onclick="location.href='student_dashboard.php'">
        </div>
        <div class="nav-buttons">
            <button class="home-btn" onclick="location.href='admin_dashboard.php'">Home</button>
            <button class="calendar-btn" onclick="location.href='calendar_admin.php'">Calendar</button>
            <button class="contact-btn" onclick="location.href='contactus.php'">Contact Us</button>
        </div>
        </div>
    
    <div class="container">
    <div class="navone-buttons">
            <div class="sidebar">
                <img src="images/hamburger-menu.svg" class="menu-btn" alt="menu">
                <h2>Calendar</h2>
                <form method="get">
    </form>
    <form method="get">
    </form>
            <div class="logout-container">
                <span class="username"><?php echo htmlspecialchars($user_name); ?></span>
                <img class="logout-btn" src="images/log-out.svg" alt="logout" onclick="window.location.href='logout.php'">
            </div>
            </div>
    </div>

    <div class="calendar-map" id="calendar"></div>
    </div>

    <script>
document.addEventListener('DOMContentLoaded', function () {
    let calendarEl = document.getElementById('calendar');

    let calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',  // Default calendar view
        headerToolbar: {
            left: 'prev,next today', // Navigation buttons
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay' // View options
        },
        selectable: true,
        editable: false, // Disable editing for now
        eventClick: function (info) {
            alert('Event: ' + info.event.title + '\nStart: ' + info.event.start);
        },
        
        events: 'fetch_events.php' // Fetch events from backend
    });

    calendar.render();
});

</script>


</body>
</html>

