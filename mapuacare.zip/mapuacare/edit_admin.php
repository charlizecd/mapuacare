<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Include database connection
include 'config.php';

// Check if user ID is provided
if (!isset($_GET['id'])) {
    header("Location: admin_dashboard.php"); // Redirect if no ID is provided
    exit();
}

$user_id = $_GET['id'];

// Fetch user details
$sql = "SELECT name, email, mapua_id_number, role FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($name, $email, $mapua_id_number, $role_id);
$stmt->fetch();
$stmt->close();

// Handle update form submission
if (isset($_POST['update_user'])) {
    $new_name = $_POST['name'];
    $new_email = $_POST['email'];
    $new_mapua_id = $_POST['mapua_id_number'];
    $new_role = $_POST['role_id'];
    
    // Check if password is provided
    if (!empty($_POST['password'])) {
        $new_password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $update_sql = "UPDATE users SET name = ?, email = ?, password = ?, mapua_id_number = ?, role = ? WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ssssii", $new_name, $new_email, $new_password, $new_mapua_id, $new_role, $user_id);
    } else {
        $update_sql = "UPDATE users SET name = ?, email = ?, mapua_id_number = ?, role = ? WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("sssii", $new_name, $new_email, $new_mapua_id, $new_role, $user_id);
    }
    
    $update_stmt->execute();
    $update_stmt->close();
    
    header("Location: admin_dashboard.php"); // Redirect after update
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 50px;
        }
        form {
            display: inline-block;
            text-align: left;
            background: #f8f8f8;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px #ccc;
        }
        input, select {
            display: block;
            width: 100%;
            margin-bottom: 10px;
            padding: 8px;
        }
        button {
            background: #f7d774;
            border: none;
            padding: 10px;
            cursor: pointer;
        }
        button:hover {
            background: #b3b3b3;
        }
    </style>
</head>
<body>

    <h2>Edit User</h2>

    <form method="POST">
        <label>Name:</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($name); ?>" required>

        <label>Email:</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>

        <label>Mapua ID Number:</label>
        <input type="text" name="mapua_id_number" value="<?php echo htmlspecialchars($mapua_id_number); ?>" required>

        <label>Password (Leave blank to keep current password):</label>
        <input type="password" name="password">

        <label>Role:</label>
        <select name="role_id" required>
            <option value="1" <?php echo ($role_id == 1) ? 'selected' : ''; ?>>Student</option>
            <option value="2" <?php echo ($role_id == 2) ? 'selected' : ''; ?>>Counselor</option>
            <option value="3" <?php echo ($role_id == 3) ? 'selected' : ''; ?>>Admin</option>
        </select>

        <button type="submit" name="update_user">Update User</button>   
    </form>
    
             <!-- Back Button -->
    <br>
    <a href="admin_dashboard.php" class="back-btn">Back to Admin Dashboard</a>

</body>
</html>
