    <?php 
    session_start();
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit();
    }

    include 'config.php';

    $user_id = $_SESSION['user_id'];

    // Fetch counselor details
    $user_name = "Unknown";
    if ($stmt = $conn->prepare("SELECT name FROM users WHERE id = ?")) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $user_name = $row['name'];
        }
        $stmt->close();
    }

    // Fetch availability slots excluding the booked ones
    $availability_slots = [];
    if ($stmt = $conn->prepare("SELECT id, date, start_time, end_time FROM availability WHERE counselor_id = ? AND status != 'booked' ORDER BY date, start_time")) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $availability_slots[] = $row;
        }
        $stmt->close();
    }

    // Handle form submission (Update availability)
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_id'])) {
        $edit_id = $_POST['edit_id'];
        $edit_date = $_POST['edit_date'];
        $edit_start_time = $_POST['edit_start_time'];
        $edit_end_time = $_POST['edit_end_time'];

        $stmt = $conn->prepare("UPDATE availability SET date=?, start_time=?, end_time=? WHERE id=?");
        $stmt->bind_param("sssi", $edit_date, $edit_start_time, $edit_end_time, $edit_id);
        $stmt->execute();
        $stmt->close();

        header("Location: view_available_date.php");
        exit();
    }
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>MapúaCARE - View Available Dates</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 0;
                background-color: #f8f8f8;
            }
            .header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 15px 40px;
                border-bottom: 2px solid black;
                background: white;
            }
            .sidebar {
                width: 330px;
                background: white;
                padding: 20px;
                display: flex;
                flex-direction: column;
                border-right: 2px solid black;
            }
            .container {
                display: flex;
                width: 100%;
            }
            .form-container {
                flex-grow: 1;
                background-color: #ffffff;
                padding: 30px;
                margin: 50px auto;
                border-radius: 15px;
                box-shadow: 0 10px 20px rgba(15, 14, 14, 0.6);
                max-width: 800px;
                border: 1px solid #ddd;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }
            th, td {
                padding: 12px;
                border: 1px solid #ddd;
                text-align: center;
            }
            th {
                background-color: #F7D774;
            }
            .edit-btn, .delete-btn, .save-btn, .cancel-btn {
                padding: 8px 12px;
                border: none;
                cursor: pointer;
                color: white;
                font-size: 14px;
                margin: 2px;
                border-radius: 4px;
            }
            .edit-btn { background-color: #28a745; }
            .delete-btn { background-color: #dc3545; }
            .save-btn { background-color: #007bff; }
            .cancel-btn { background-color: #6c757d; }
            .hidden { display: none; }
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 0;
                background-color: #f8f8f8;
            }
            .header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 15px 40px;
                border-bottom: 2px solid black;
                background: white;
            }
            .logo img {
                height: auto;
                width: auto;
            }
            .nav-buttons {
                display: flex;
                gap: 20px;
            }
            .nav-buttons button {
                padding: 10px 40px;
                border: none;
                cursor: pointer;
                font-size: 16px;
                transition: background 0.3s ease;
            }
            .home-btn {
                background: #F7D774;
                margin-left: 100px;
            }
            .calendar-btn, .contact-btn {
                background: #ccc;
                margin-left: 100px;
            }
            .contact-btn {
                margin-right: 115px;
            }
            .nav-buttons button:hover {
                background: #b3b3b3;
            }
            .sidebar {
                width: 330px;
                background: white;
                padding: 20px;
                left: 0;
                top: 0;
                display: flex;
                flex-direction: column;
                border-right: 2px solid black;
            }
            h2 {
                margin-left: 20px;
                font-size: 30px;
                margin-top: 0px;
            }
            .add-btn {
                margin-top: 70px;
                background: #ccc;
                margin-bottom: 20px;
            }
            .appoint-btn {
                margin-bottom: 70px;
                background: #ccc;
            }
            .view-btn {
                background: rgb(241, 63, 63);
                margin-bottom: 20px;
            }
            .navone-buttons {
                display: flex;
                gap: 20px;
            }
            .navone-buttons button {
                padding: 25px 40px;
                border: none;
                cursor: pointer;
                font-size: 16px;
                transition: background 0.3s ease;
            }
            .navone-buttons button:hover {
                background: rgb(236, 31, 31);
            }
            .logout-container { 
                display: flex;
                align-items: center;
                padding-left: 5px;
                background-color: #F7D774;
                height: 65px;
                border-radius: 20px;
            }
            .username {
                font-size: 18px;
                font-weight: bold;
                margin-left: 20px;
            }
            .logout-btn {
                width: 40px;
                cursor: pointer;
                margin-left: 150px;
            }
            .menu-btn {
                width: 40px;
                margin-left: 300px;
                cursor: pointer;
            }

            /* Card container styling */
            .form-container {
                flex-grow: 1;
                background-color: #ffffff;
                padding: 30px;
                margin: 50px auto; /* Centering the form with margin */
                border-radius: 15px; /* Rounded corners for the card effect */
                box-shadow: 0 10px 20px rgba(15, 14, 14, 0.6); /* Soft shadow for depth */
                max-width: 800px; /* Limiting the width for a card effect */
                box-sizing: border-box;
                border: 1px solid #ddd; /* Subtle border to define the card */
            }

            /* Form title */
            .form-container h3 {
                font-size: 24px;
                font-weight: bold;
                margin-bottom: 20px;
                color: #333;
                text-align: center;
                border-bottom: 2px solid #ddd; /* Subtle divider under title */
                padding-bottom: 10px;
            }

            /* Table Styling */
            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }
            th, td {
                padding: 12px;
                border: 1px solid #ddd;
                text-align: center;
            }
            th {
                background-color: #F7D774;
            }

            .message {
                background-color: #f9f9f9;
                border: 1px solid #ddd;
                padding: 15px;
                margin-bottom: 20px;
                border-radius: 8px;
                font-size: 16px;
                color: #333;
                text-align: center;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }

            .container{
                display: flex;
                flex-direction: row; /* Side by side */
                width: 100%;
            }
        </style>
    </head>
    <body>

    <div class="header">
            <div class="logo">
                <img src="images/logo.png" alt="MapúaCARE" onclick="location.href='counselor_dashboard.php'">
            </div>
            <div class="nav-buttons">
                <button class="home-btn" onclick="location.href='counselor_dashboard.php'">Home</button>
                <button class="calendar-btn" onclick="location.href='calendar_counselor.php'">Calendar</button>
                <button class="contact-btn" onclick="location.href='contactus.php'">Contact Us</button>
            </div>
        </div>

        <div class="container">
            <div class="navone-buttons">
                <div class="sidebar">
                    <img src="images/hamburger-menu.svg" class="menu-btn" alt="menu">
                    <h2>Home</h2>
                    <button class="add-btn" onclick="location.href='add_availability.php'">Add Available Dates</button>
                    <button class="view-btn" onclick="location.href='view_available_date.php'">View Available Dates</button>
                    <button class="appoint-btn" onclick="location.href='view_counselor.php'">View Appointment</button>
                    <div class="logout-container">
                        <span class="username"><?php echo htmlspecialchars($user_name); ?></span>
                        <img class="logout-btn" src="images/log-out.svg" alt="logout" onclick="window.location.href='logout.php'">
                    </div>
                </div>
            </div>

            <div class="form-container">
                <h3>Your Available Dates</h3>

                <?php if (empty($availability_slots)) { ?>
                    <div class="message">You have not added any availability yet.</div>
                <?php } else { ?>
                    <table>
                        <tr>
                            <th>Date</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th></th>
                        </tr>
                        <?php foreach ($availability_slots as $slot) { ?>
                            <tr id="row-<?php echo $slot['id']; ?>">
                                <!-- Normal View -->
                                <td class="view-mode"><?php echo htmlspecialchars($slot['date']); ?></td>
                                <td class="view-mode"><?php echo htmlspecialchars($slot['start_time']); ?></td>
                                <td class="view-mode"><?php echo htmlspecialchars($slot['end_time']); ?></td>

                                <!-- Edit Mode -->
                                <td class="edit-mode hidden">
                                    <input type="date" id="date-<?php echo $slot['id']; ?>" value="<?php echo htmlspecialchars($slot['date']); ?>">
                                </td>
                                <td class="edit-mode hidden">
                                    <input type="time" id="start-<?php echo $slot['id']; ?>" value="<?php echo htmlspecialchars($slot['start_time']); ?>">
                                </td>
                                <td class="edit-mode hidden">
                                    <input type="time" id="end-<?php echo $slot['id']; ?>" value="<?php echo htmlspecialchars($slot['end_time']); ?>">
                                </td>

                                <td>
                                    <button class="edit-btn" onclick="enableEdit(<?php echo $slot['id']; ?>)">Edit</button>
                                    <button class="delete-btn" onclick="deleteAvailability(<?php echo $slot['id']; ?>)">Delete</button>

                                    <button class="save-btn hidden" onclick="saveEdit(<?php echo $slot['id']; ?>)">Save</button>
                                    <button class="cancel-btn hidden" onclick="cancelEdit(<?php echo $slot['id']; ?>)">Cancel</button>
                                </td>
                            </tr>
                        <?php } ?>
                    </table>
                <?php } ?>
            </div>
        </div>

        <script>
            function enableEdit(id) {
                document.querySelectorAll("#row-" + id + " .view-mode").forEach(el => el.classList.add("hidden"));
                document.querySelectorAll("#row-" + id + " .edit-mode").forEach(el => el.classList.remove("hidden"));
                document.querySelector("#row-" + id + " .edit-btn").classList.add("hidden");
                document.querySelector("#row-" + id + " .delete-btn").classList.add("hidden");
                document.querySelector("#row-" + id + " .save-btn").classList.remove("hidden");
                document.querySelector("#row-" + id + " .cancel-btn").classList.remove("hidden");
            }

            function cancelEdit(id) {
                location.reload(); // Reloads to cancel edits
            }

            function saveEdit(id) {
                let date = document.getElementById("date-" + id).value;
                let start = document.getElementById("start-" + id).value;
                let end = document.getElementById("end-" + id).value;

                let form = new FormData();
                form.append("edit_id", id);
                form.append("edit_date", date);
                form.append("edit_start_time", start);
                form.append("edit_end_time", end);

                fetch("view_available_date.php", { method: "POST", body: form })
                    .then(() => location.reload());
            }
            function deleteAvailability(id) {
        if (confirm("Are you sure you want to delete this availability slot?")) {
            let form = new FormData();
            form.append("delete_id", id);

            fetch("delete_availability.php", {
                method: "POST",
                body: form
            })
            .then(response => response.text())
            .then(data => {
                if (data.trim() === "success") {
                    document.getElementById("row-" + id).remove(); // Remove row without reloading
                } else {
                    alert("Failed to delete availability slot.");
                }
            });
        }
    }
        </script>

    </body>
    </html>
