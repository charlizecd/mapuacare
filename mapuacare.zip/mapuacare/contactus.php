<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MapúaCARE - Contact Us</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f8f8;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 40px;
            border-bottom: 2px solid black;
            background: white;
        }
        .logo img {
            height: auto;
            width: auto;
        }
        .nav-buttons {
            display: flex;
            gap: 20px;
        }
        .nav-buttons button {
            padding: 10px 40px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s ease;
        }
        .home-btn {
            background: #ccc;
            margin-left: 100px;
        }
        .calendar-btn{
            background: #ccc;
            margin-left: 100px;
            margin-right: 100px;
        }
        .contact-btn {
            margin-right: 100px;
            background: #F7D774;

        }
        .login-btn{
            background: #ccc;
            margin-left: 100px;
            margin-right: 100px;
        }
        .nav-buttons button:hover {
            background: #b3b3b3;
        }

        /* Main Layout */
        h2 {
            text-align: left;
            margin-top: 60px;
            margin-bottom: 20px;
            margin-left: 80px;
            font-size: 30px;
        }
        .container {
            display: flex;
            justify-content: center;
            gap: 30px;
            padding: 20px;
            max-width: 900px;
            margin: auto;
        }
        .left-section, .right-section {
            flex: 0.8; /* Reduced width */
        }

        /* Left Section */
        .contact-box {
            background: #ddd;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 15px;
            text-align: center;
        }
        .contact-box a, .contact-box p {
            text-decoration: none;
            color: black;
            font-size: 14px;
        }
        .contact-box a:hover {
            color: #555;
        }
        iframe {
            width: 100%;
            height: 180px;
            border: 0;
            border-radius: 5px;
            margin-top: 10px;
        }

        /* Right Section */
        .message-box {
            background: #ddd;
            padding: 40px;
            border-radius: 5px;
            text-align: left;
        }
        .message-box input, .message-box textarea {
            width: 95%;
            padding: 8px;
            margin: 5px 0;
            border-radius: 5px;
            border: 1px solid #aaa;
            font-size: 14px;
        }
        .submit-btn {
            background:rgb(244, 210, 95);
            padding: 8px 8px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            border-radius: 5px;
            width: 100%;
            transition: background 0.3s ease;
        }
        .submit-btn:hover {
            background: #e6c44f;
        }

         /* Footer Styling */
         footer {
            background: black;
            color: white;
            text-align: center;
            padding: 15px 0;
            margin-top: 50px;
        }
        .footer-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 900px;
            margin: auto;
            padding: 0 20px;
        }
        .social-icons {
            display: flex;
            gap: 10px;
        }
        .social-link {
            text-decoration: none;
            color: white;
            font-weight: bold;
            font-size: 14px;
            transition: color 0.3s ease;
        }
        .social-link:hover {
            color: #F7D774;
        }
    </style>
</head>
<body>


<div class="header">
        <div class="logo">
            <img src="images/logo.png" alt="MapúaCARE">
        </div>
        <div class="nav-buttons">
    <?php if (isset($_SESSION['role'])): ?>
        <?php if ($_SESSION['role'] === 0): ?>
            <button class="home-btn" onclick="location.href='student_dashboard.php'">Home</button>
            <button class="calendar-btn" onclick="location.href='calendar_student.php'">Calendar</button>
        <?php elseif ($_SESSION['role'] === 1): ?>
            <button class="home-btn" onclick="location.href='counselor_dashboard.php'">Home</button>
            <button class="calendar-btn" onclick="location.href='calendar_counselor.php'">Calendar</button>
        <?php elseif ($_SESSION['role'] === 2): ?>
            <button class="home-btn" onclick="location.href='admin_dashboard.php'">Home</button>
            <button class="calendar-btn" onclick="location.href='calendar_admin.php'">Calendar</button>
        <?php endif; ?>
    <?php else: ?>
        <button class="home-btn" onclick="location.href='index.php'">About</button>
        <button class="login-btn" onclick="location.href='login.php'">Login</button>
    <?php endif; ?>
    <button class="contact-btn" onclick="location.href='contactus.php'">Contact Us</button>
</div>


    </div>

    <h2>Contact Us</h2>

    <div class="container">
        <!-- Left Section -->
        <div class="left-section">
            <div class="contact-box">
                <h3>Working Hours</h3>
                <p><b>8:00 A.M - 5:00 P.M</b></p>
            </div>

            <div class="contact-box">
                <h3>Email</h3>
                <a href="mailto:mapuacare@mymail.mapua.edu.ph">mapuacare@mymail.mapua.edu.ph</a>
                <p><b>(+632) 8247-5000 loc. 5805</b></p>
            </div>

            <div class="contact-box">
                <h3>Location</h3>
                <a href="https://maps.app.goo.gl/Po6imXQB3UqGb2s36" target="_blank">
                    1191 Pablo Ocampo Sr. Ext, Makati, Metro Manila
                </a>
                <iframe src="https://www.google.com/maps?q=1191+Pablo+Ocampo+Sr+Ext,+Makati,+Metro+Manila&output=embed" allowfullscreen></iframe>
            </div>
        </div>

        <!-- Right Section -->
        <div class="right-section">
            <div class="message-box">
                <h3>Message Us</h3>
                <form action="send_message.php" method="POST">
                    <label>Name:</label>
                    <input type="text" name="name" required>

                    <label>Email:</label>
                    <input type="email" name="email" required>

                    <label>Message:</label>
                    <textarea name="message" rows="4" required></textarea>

                    <button type="submit" class="submit-btn">Send Message</button>
                </form>
                <?php
                if (isset($_GET['success'])) {
                    echo "<p style='color:green;'>Message submitted successfully!</p>";
                }
                ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-container">
            <p>&copy; 2025 MapúaCARE. All rights reserved.</p>
            <div class="social-icons">
                <a href="#" class="social-link">Facebook</a>
                <a href="#" class="social-link">Twitter</a>
                <a href="#" class="social-link">Instagram</a>
            </div>
        </div>
    </footer>

</body>
</html>
