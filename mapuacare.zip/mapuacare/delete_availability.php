<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];
    $user_id = $_SESSION['user_id'];

    // Ensure the user can only delete their own availability slots if not booked
    $stmt = $conn->prepare("DELETE FROM availability WHERE id = ? AND counselor_id = ? AND status != 'booked'");
    $stmt->bind_param("ii", $delete_id, $user_id);

    if ($stmt->execute() && $stmt->affected_rows > 0) {
        echo "success"; // Return plain text response
    } else {
        echo "error"; // Return "error" if deletion fails
    }

    $stmt->close();
    $conn->close();
} else {
    echo "invalid"; // Handle invalid requests
}
?>
    