<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = htmlspecialchars($_POST['email'], ENT_QUOTES, 'UTF-8');
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE email = ? LIMIT 1";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

 // Check if user exists and verify password 
if ($user && password_verify($password, $user['password'])) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = $user['role'];

    // Redirect based on role
    if ($user['role'] == 0) { // Student
        header("Location: student_dashboard.php");
        exit();
    } else if ($user['role'] == 1) { // Counselor
        header("Location: counselor_dashboard.php");
        exit();
    } else if ($user['role'] == 2) { // Admin (or any other role you intend)
        header("Location: admin_dashboard.php");
        exit();
    }
} else {
    echo "<script>alert('Invalid email or password!'); window.location.href='login.php';</script>";
    exit();
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MapúaCARE - Login</title>
    <style>
        /* General Styles */
body {
    font-family: Arial, sans-serif;
    background-color: white;
    text-align: center;
    margin: 0;
    padding: 0;
}

/* Container */
.container {
    margin-top: 100px;
}

/* Login Box */
.login-box {
    width: 600px;
    margin: 20px auto;
    padding: 20px;
    border: 2px solid red;
    border-radius: 10px;
    text-align: left;
}

/* Input Fields */
input {
    width: 95%;
    padding: 15px;
    margin: 5px 0 15px 0;
    border: 1px solid lightgray;
    border-radius: 5px;
    font-size: 16px;
}

/* Login Button */
.login-btn {
    width: 100%;
    padding: 10px;
    background-color: red;
    color: white;
    border: none;
    border-radius: 5px;
    font-size: 18px;
    cursor: pointer;
}

.login-btn:hover {
    background-color: darkred;
}

/* Forgot Password Link */
.forgot-password {
    display: block;
    text-align: left;
    color: red;
    margin-top: 20px;
    margin-bottom: 20px;
    text-decoration: none;
}

.forgot-password:hover {
    text-decoration: underline;
}

/* Register Link */
.register-text {
    margin-top: 20px;
}

.register-link {
    color: red;
    font-weight: bold;
    text-decoration: none;
}

.register-link:hover {
    text-decoration: underline;
}

.logo-container {
    text-align: center;
    margin-bottom: 10px;
}

.logo {
    width: auto; /* Adjust size */
    height: auto;
    padding-bottom: 20px;
    cursor: pointer; /* Changes cursor to pointer */
    transition: transform 0.3s ease, opacity 0.3s ease; /* Smooth animation */
}
.logo:hover {
    transform: scale(1.1); /* Slight zoom effect */
    opacity: 0.8; /* Slight transparency */
}


    </style>
</head>
<body>

    <div class="container">
        <div class="logo-container">
            <img src="images/logo.png" alt="MapúaCARE Logo" class="logo" onclick=" location.href='index.php'">
        </div>

        <div class="login-box">
            <form action="login.php" method="POST">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="Email" required>

                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Password" required>

                <button type="submit" class="login-btn">Sign In</button>
            </form>
            
            <a href="#" class="forgot-password">Forgot password?</a>
        </div>

        <p class="register-text">Don’t have an account yet? <a href="signup.php" class="register-link">Register/Sign up</a></p>
    </div>

    <script>
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
</script>


</body>
</html>
