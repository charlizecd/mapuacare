<?php  
session_start();
require_once 'config.php'; // Database connection

// Fetch user details
$user_id = $_SESSION['user_id'];
$sql = "SELECT name FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($user_name);
$stmt->fetch();
$stmt->close();

// Google OAuth Config
$client_id = "983689228993-25gqcjkkiigo21ev980gujglnf84fkk4.apps.googleusercontent.com";
$client_secret = "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";
$redirect_uri = "http://localhost/counseling/calendar_counselor.php";
$scope = "https://www.googleapis.com/auth/calendar";

// If user clicks "Sync to Google Calendar" button
if (isset($_GET['sync'])) {
    $auth_url = "https://accounts.google.com/o/oauth2/auth?"
        . "response_type=code"
        . "&client_id=" . urlencode($client_id)
        . "&redirect_uri=" . urlencode($redirect_uri)
        . "&scope=" . urlencode($scope)
        . "&access_type=offline";

    header("Location: $auth_url");
    exit;
}

// Step 2: Exchange Code for Access Token
if (isset($_GET['code'])) {
    $code = $_GET['code'];

    $token_request = [
        'code' => $code,
        'client_id' => $client_id,
        'client_secret' => $client_secret,
        'redirect_uri' => $redirect_uri,
        'grant_type' => 'authorization_code'
    ];

    $ch = curl_init('https://oauth2.googleapis.com/token');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($token_request));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);
    $response = curl_exec($ch);
    curl_close($ch);

    $token_data = json_decode($response, true);

    if (!isset($token_data['access_token'])) {
        die("Error retrieving access token.");
    }

    $_SESSION['access_token'] = $token_data['access_token'];

    header('Location: calendar_counselor.php');
    exit;
}

// Step 3: Sync Counselor Appointments to Google Calendar
if (isset($_SESSION['access_token'])) {
    $access_token = $_SESSION['access_token'];
    $calendar_id = 'primary';

    if (!isset($_SESSION['user_id'])) {
        die("Error: Counselor ID not found in session.");
    }
    $counselor_id = $_SESSION['user_id'];

    // Fetch counselor appointments from the database
$query = "SELECT id, date, start_time, end_time FROM appointments WHERE counselor_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $counselor_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Combine date with start_time and end_time
        $startDateTime = new DateTime("{$row['date']} {$row['start_time']}", new DateTimeZone('Asia/Manila'));
        $endDateTime = new DateTime("{$row['date']} {$row['end_time']}", new DateTimeZone('Asia/Manila'));

        $event_data = [
            'summary' => "Counseling Appointment",
            'start' => [
                'dateTime' => $startDateTime->format('c'), // ISO 8601 format
                'timeZone' => 'Asia/Manila'
            ],
            'end' => [
                'dateTime' => $endDateTime->format('c'), // ISO 8601 format
                'timeZone' => 'Asia/Manila'
            ]
        ];

        // Check if event exists in Google Calendar
        $existingEventQuery = "SELECT google_event_id FROM calendar_sync WHERE appointment_id = ?";
        $stmt2 = $conn->prepare($existingEventQuery);
        $stmt2->bind_param("i", $row['id']);
        $stmt2->execute();
        $existingEvent = $stmt2->get_result()->fetch_assoc();

        if ($existingEvent) {
            // Update existing event
            $eventId = $existingEvent['google_event_id'];
            $url = "https://www.googleapis.com/calendar/v3/calendars/$calendar_id/events/$eventId";

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($event_data));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $access_token,
                'Content-Type: application/json'
            ]);
            curl_exec($ch);
            curl_close($ch);
        } else {
            // Insert new event
            $ch = curl_init("https://www.googleapis.com/calendar/v3/calendars/$calendar_id/events");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($event_data));
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $access_token,
                'Content-Type: application/json'
            ]);

            $response = curl_exec($ch);
            curl_close($ch);

            $createdEvent = json_decode($response, true);

            if (isset($createdEvent['id'])) {
                $eventId = $createdEvent['id'];
                $insertSync = "INSERT INTO calendar_sync (appointment_id, google_event_id) VALUES (?, ?)";
                $stmt3 = $conn->prepare($insertSync);
                $stmt3->bind_param("is", $row['id'], $eventId);
                $stmt3->execute();
            }
        }
    }
}
}

// ========== UNSYNC (DISCONNECT) FEATURE ==========
if (isset($_GET['unsync'])) {
    if (isset($_SESSION['access_token'])) {
        $access_token = $_SESSION['access_token'];
        $calendar_id = 'primary';

        // Fetch and remove synced events from Google Calendar
        $query = "SELECT google_event_id FROM calendar_sync WHERE google_event_id IS NOT NULL";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($row = $result->fetch_assoc()) {
            $eventId = $row['google_event_id'];
            $deleteUrl = "https://www.googleapis.com/calendar/v3/calendars/$calendar_id/events/$eventId";

            $ch = curl_init($deleteUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Authorization: Bearer ' . $access_token,
                'Content-Type: application/json'
            ]);
            curl_exec($ch);
            curl_close($ch);
        }

        // Remove synced records from the database
        $deleteSyncQuery = "DELETE FROM calendar_sync WHERE google_event_id IS NOT NULL";
        $stmt = $conn->prepare($deleteSyncQuery);
        $stmt->execute();

        // Revoke access from Google
        $revoke_url = "https://accounts.google.com/o/oauth2/revoke?token=" . $access_token;
        $ch = curl_init($revoke_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_exec($ch);
        curl_close($ch);

        // ✅ Remove only Google access, keep the session
        unset($_SESSION['access_token']);

        // ✅ Redirect to prevent form resubmission issues
        header("Location: calendar_counselor.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MapúaCARE - Home</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.11.5/main.min.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/5.11.5/main.min.js"></script>

    <style>
         body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f8f8;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 40px;
            border-bottom: 2px solid black;
            background: white;
        }
        .logo img {
            height: auto;
            width: auto;
        }
        .nav-buttons {
            display: flex;
            gap: 20px;
        }
        .nav-buttons button {
            padding: 10px 40px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s ease;
        }
        .home-btn {
            background: #ccc;
            margin-left: 100px;
        }
        .calendar-btn {
            background: #F7D774;
            margin-left: 100px;
        }
        .contact-btn {
            margin-right: 115px;
            margin-left: 100px;
            background: #ccc;


        }
        .nav-buttons button:hover {
            background: #b3b3b3;
        }
        .sidebar {
    width: 330px;
    height: 600px; 
    background: #ffffff;
    padding: 30px 20px;
    display: flex;
    flex-direction: column;
    border-right: 2px solid black;
    box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
}

/* Center text and add spacing */
h2 {
    font-size: 28px;
    text-align: left;
    color: #333;
    margin-bottom: 100px;
    margin-left: 10px;
}

/* Button Styles */
.sidebar button {
    width: 100%;
    padding: 15px;
    font-size: 16px;
    border: none;
    cursor: pointer;
    transition: background 0.3s ease, transform 0.2s;
    margin: 10px 0 ; /* Add space between buttons */
    border-radius: 0px;
}

.book-btn {
    background: #ccc;
    color: #333;
    font-weight: bold;
}

.appoint-btn {
    background: #ccc;
    color: #333;
    font-weight: bold;
}

/* Hover Effects */
.sidebar button:hover {
    transform: scale(1.05);
    opacity: 0.9;
}

/* Menu Icon */
.menu-btn {
    width: 40px;
    margin-left: 290px;
    display: block;
    cursor: pointer;
}
        .logout-container { 
            display: flex;
            align-items: center;
            padding-left: 5px;
            background-color: #F7D774;
            height: 65px;
            border-radius: 20px;
            margin-top: 120px;

        }
        .username {
            font-size: 18px;
            font-weight: bold;
            margin-left: 20px;
        }
        .logout-btn {
            width: 40px;
            cursor: pointer;
            margin-left: 150px;
        }
        .content {
            margin-left: 320px;
            padding: 20px;
        }
        .calendar-container {
            width: 100%;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }
        .container{
            display: flex;
            flex-direction: row; /* Side by side */
            width: 100%;
        } 
        .calendar-map{
    width: 100%;
    height: 650px;
    border: none;

}
/* Change toolbar background */
.calendar-map .fc-toolbar {
    background-color: white; /* Dark background */
    color: black; /* Text color */
    border-radius: 5px;
}

/* Change navigation buttons (prev, next, today) */
.calendar-map .fc-button {
    background-color:rgba(246, 0, 0, 0.78) !important;
    border: none;
    border-radius: 5px;
}

/* Change hover effect */
.calendar-map .fc-button:hover {
    background-color:   rgba(18, 18, 19, 0.21) !important; 
}

/* Change active button (month, week, day) */
.calendar-map .fc-button-active {
    background-color:rgba(239, 171, 23, 0.98) !important;
    color: white !important;
}

/* Change title (March 2025) */
.calendar-map .fc-toolbar-title {
    font-size: 20px;
    font-weight: bold;
    color: #222; /* Change title color */
}

    </style>
</head>
<body>

    <div class="header">
        <div class="logo">
            <img src="images/logo.png" alt="MapúaCARE" onclick="location.href='counselor_dashboard.php'">
        </div>
        <div class="nav-buttons">
            <button class="home-btn" onclick="location.href='counselor_dashboard.php'">Home</button>
            <button class="calendar-btn" onclick="location.href='calendar_counselor.php'">Calendar</button>
            <button class="contact-btn" onclick="location.href='contactus.php'">Contact Us</button>
        </div>
        </div>
    
    <!-- SYNC TO GOOGLE CALENDAR BUTTON -->
    <div class="container">
    <div class="navone-buttons">
            <div class="sidebar">
                <img src="images/hamburger-menu.svg" class="menu-btn" alt="menu">
                <h2>Calendar</h2>
                <form method="get">
        <button type="submit" name="sync" class="book-btn" >Sync Calendar</button>
    </form>
    <!-- UNSYNC BUTTON -->
    <form method="get">
        <button type="submit" name="unsync" class="appoint-btn">Unsync Calendar</button>
    </form>
            <div class="logout-container">
                <span class="username"><?php echo htmlspecialchars($user_name); ?></span>
                <img class="logout-btn" src="images/log-out.svg" alt="logout" onclick="window.location.href='logout.php'">
            </div>
            </div>
    </div>

    <div class="calendar-map" id="calendar"></div>
    </div>

    <script>
document.addEventListener('DOMContentLoaded', function () {
    let calendarEl = document.getElementById('calendar');

    let calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',  // Default calendar view
        headerToolbar: {
            left: 'prev,next today', // Navigation buttons
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay' // View options
        },
        selectable: true,
        editable: false, // Disable editing for now
        eventClick: function (info) {
            alert('Event: ' + info.event.title + '\nStart: ' + info.event.start);
        },
        
        events: 'fetch_events.php' // Fetch events from backend
    });

    calendar.render();
});

</script>


</body>
</html>

