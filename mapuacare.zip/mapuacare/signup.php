<?php
session_start();
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name'], ENT_QUOTES, 'UTF-8');
    $email = htmlspecialchars($_POST['email'], ENT_QUOTES, 'UTF-8');
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Secure password hashing
    $mapua_id_number = htmlspecialchars($_POST['mapua_id_number'], ENT_QUOTES, 'UTF-8');

    // Check if the email or Mapúa ID already exists
    $check_query = "SELECT id FROM users WHERE email = ? OR mapua_id_number = ? LIMIT 1";
    $stmt = $conn->prepare($check_query);
    $stmt->bind_param("ss", $email, $mapua_id_number);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "<script>alert('Email or Mapúa ID number already exists!'); window.location.href='signup.php';</script>";
        exit();
    }

    // Insert new user into database
    $query = "INSERT INTO users (name, email, password, mapua_id_number) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssss", $name, $email, $password, $mapua_id_number);

    if ($stmt->execute()) {
        echo "<script>alert('Registration successful! Please log in.'); window.location.href='login.php';</script>";
    } else {
        echo "<script>alert('Error: Unable to register.'); window.location.href='signup.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MapúaCARE - Sign Up</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: white;
    text-align: center;
}

.container {
    width: 500px;
    margin: 20px auto;
    padding: 20px;
    border: 1px solid #f00;
    border-radius: 8px;
}

.logo-container {
    margin-bottom: 0px;
    padding-top: 0px;
}

.logo {
    width: auto; /* Adjust size */
    height: auto;
}


h2 {
    font-size: 20px;
    margin-bottom: 20px;
}

.signup-box input {
    text-align: left;
    width: 95%;
    padding: 15px;
    margin:5px 0 15px 0;
    border: 2px solid #ccc;
    border-radius: 10px;
}

.signup-btn {
    background-color: #f00;
    color: white;
    border: none;
    padding: 10px;
    width: 100%;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
}

.login-link {
    color: #f00;
    text-decoration: none;
}

.login-link:hover {
    text-decoration: underline;
}
    </style>
</head>
<body>

     <div class="logo-container">
            <img src="images/logo.png" alt="MapúaCARE Logo" class="logo">
    </div>

    <div class="container">
        <div class="signup-box">
            <h2>Create an Account</h2>
            <form action="signup.php" method="POST">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" placeholder="Full Name" required>

                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="Email" required>

                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Password" required>

                <label for="mapua_id_number">Mapúa ID Number</label>
                <input type="text" id="mapua_id_number" name="mapua_id_number" placeholder="Mapúa ID Number" required>

                <button type="submit" class="signup-btn">Sign Up</button>
            </form>

            <p class="login-text">Already have an account? <a href="login.php" class="login-link">Login Here</a></p>
        </div>
    </div>

</body>
</html>
