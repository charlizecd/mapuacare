<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> MapúaCARE</title>
    <style>
         body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f8f8;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 40px;
            border-bottom: 2px solid black;
            background: white;
        }
        .logo img {
            height: auto;
            width: auto;
        }
        .nav-buttons {
            display: flex;
            gap: 20px;
        }
        .nav-buttons button {
            padding: 10px 30px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s ease;
        }
        .home-btn {
            background: #F7D774;
            margin-left: 100px;
        }
        .login-btn, .contact-btn {
            background: #ccc;
            margin-left: 100px;
        }
        .contact-btn {
            margin-right: 200px;
        }
        .nav-buttons button:hover {
            background: #b3b3b3;
        }

        /* Content Section */
        .content {
        }
        .content h2 {
            font-size: 40px;
            font-weight: bold;
            text-align: left;
            margin-left: 100px  ;
            margin-bottom: 90px;
            margin-top: 50px;
        }
        .content p {
            font-size: 25px;
            text-align: left;
            margin-left: 200px;
            margin-right: 200px;
            margin-bottom: 70px;
        }
        .image-container {
            margin-top: 20px;
        }
        .image-container img {
            width: 100%;
            max-width: 600px;
            height: auto;
            display: block;
            margin: 0 auto;
            border-radius: 10px;
        }
                 /* Footer Styling */
                 footer {
            background: black;
            color: white;
            text-align: center;
            padding: 10px 0;
            margin-top: 50px;
        }
        .footer-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1000px;
            margin: auto;
            padding: 0 20px;
        }
        .social-icons {
            display: flex;
            gap: 15px;
        }
        .social-link {
            text-decoration: none;
            color: white;
            font-weight: bold;
            transition: color 0.3s ease;
        }
        .social-link:hover {
            color: #F7D774;
        }
    </style>
</head>
<body>

    <div class="header">
        <div class="logo">
            <img src="images/logo.png" alt="MapúaCARE">
        </div>
        <div class="nav-buttons">
            <button class="home-btn" onclick="location.href='index.php'">About</button>
            <button class="login-btn" onclick="location.href='login.php'">Login</button>
            <button class="contact-btn" onclick="location.href='contactus.php'">Contact Us</button>
        </div>
    </div>  

    <div class="content">
        <h2>Center for Guidance and Counseling</h2>
        <p>
            The Center for Guidance and Counseling (CGC) is an essential part of Mapúa University dedicated to the holistic development of students.
            Aligned with the university's vision and mission to foster an inclusive and diverse environment, the university is committed to providing equal
            opportunities for all learners, including those with special needs, to access, participate in, and enjoy the benefits of higher education.
        </p>
        </div>

        <div class="image-container">
            <img src="images/cgc.png" alt="Center for Guidance and Counseling">
        </div>

               <!-- Footer -->
               <footer>
        <div class="footer-container">
            <p>&copy; 2025 MapúaCARE. All rights reserved.</p>
            <div class="social-icons">
                <a href="#" class="social-link">Facebook</a>
                <a href="#" class="social-link">Twitter</a>
                <a href="#" class="social-link">Instagram</a>
            </div>
        </div>
    </footer>


</body>
</html>
