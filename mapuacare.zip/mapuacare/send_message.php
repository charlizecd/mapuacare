<?php
// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Redirect back to contactus.php with a success message
    header("Location: contactus.php?success=1");
    exit();
} else {
    // If accessed directly, redirect to contactus.php
    header("Location: contactus.php");
    exit();
}
?>
