<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
// Include your database connection
include 'config.php';

// Fetch user details
$user_id = $_SESSION['user_id'];
$sql = "SELECT name FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($user_name);
$stmt->fetch();
$stmt->close();
// Prevent cached access
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MapúaCARE - Home</title>
    <style>
         body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f8f8;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 40px;
            border-bottom: 2px solid black;
            background: white;
        }
        .logo img {
            height: auto;
            width: auto;
        }
        .nav-buttons {
            display: flex;
            gap: 20px;
        }
        .nav-buttons button {
            padding: 10px 40px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s ease;
        }
        .home-btn {
            background: #F7D774;
            margin-left: 100px;
        }
        .calendar-btn, .contact-btn {
            background: #ccc;
            margin-left: 100px;
        }
        .contact-btn {
            margin-right: 115px;
        }
        .nav-buttons button:hover {
            background: #b3b3b3;
        }
        .sidebar {
            width: 330px;
            height: ;
            background: white;
            padding: 20px;
            left: 0;
            top: 0;
            display: flex;
            flex-direction: column;
            border-right: 2px solid black;
        }
        h2{
            margin-left: 20px;
            font-size: 30px;
            margin-top: 0px;
        }
    .add-btn{
        margin-top: 70px;
        background: #ccc;
        margin-bottom: 20px;
    }
    .appoint-btn{
        margin-bottom: 30px;
        background: #ccc;
    }
    .view-btn{
        background: #ccc;
        margin-bottom: 20px;
    }
    .navone-buttons {
            display: flex;
            gap: 20px;
        }
        .navone-buttons button {
            padding: 25px 40px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s ease;
        }
        .navone-buttons button:hover {
            background:rgb(236, 31, 31);
        }
        .logout-container { 
    display: flex;
    align-items: center;
    padding-left: 5px; /* Adjust for alignment */
    background-color: #F7D774;
    height: 65px;
    border-radius: 20px;
}

.username {
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 3px;
    margin-left: 20px;
}

.logout-btn {
    width: 40px;
    cursor: pointer;
    margin-left: 150px;
    margin-bottom: 3px;
}
.menu-btn{
    width: 40px;
    margin-left: 300px;
    cursor: pointer;
}

    </style>
</head>
<div>

    <div class="header">
        <div class="logo">
            <img src="images/logo.png" alt="MapúaCARE" onclick="location.href='counselor_dashboard.php'">
        </div>
        <div class="nav-buttons">
            <button class="home-btn" onclick="location.href='counselor_dashboard.php'">Home</button>
            <button class="calendar-btn" onclick="location.href='calendar_counselor.php'">Calendar</button>
            <button class="contact-btn" onclick="location.href='contactus.php'">Contact Us</button>
        </div>
    </div>
    <div class="navone-buttons">
    <div class="sidebar">
    <img src="images/hamburger-menu.svg" class="menu-btn" alt="menu">
        <h2>Home</h2>
        <button class="add-btn" onclick="location.href='add_availability.php'">Add Available Dates</button>
        <button class="view-btn"onclick="location.href='view_available_date.php'">View Available Dates </button>
        <button class="appoint-btn" onclick="location.href='view_counselor.php'">View Appointment</button>
    </div>
    </div>
        <div class="sidebar">
        <div class="logout-container">
    <span class="username"><?php echo htmlspecialchars($user_name); ?></span>
    <img src="images/log-out.svg" class="logout-btn" alt="logout" onclick="location.href='logout.php'">
</div>
        </div>

    </body>
</html>


    


