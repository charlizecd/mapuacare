from flask import Flask, jsonify
import pandas as pd
import numpy as np
import mysql.connector
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from datetime import datetime

app = Flask(__name__)

# Function to connect to MySQL
def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="mapuacare_db"
    )

# Load past appointment data (or generate sample data)
def load_past_appointments():
    try:
        df = pd.read_csv("past_appointments.csv")
    except FileNotFoundError:
        # Generate sample data if CSV is missing
        data = {
            "date": pd.date_range(start="2024-03-01", periods=50, freq="D").strftime("%Y-%m-%d"),
            "start_time": np.random.choice(["08:00", "09:00", "10:00", "14:00", "15:00"], 50),
            "end_time": np.random.choice(["09:00", "10:00", "11:00", "15:00", "16:00"], 50),
            "day_of_week": np.random.choice(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"], 50),
            "status": np.random.choice(["booked", "available"], 50)
        }
        df = pd.DataFrame(data)
    
    return df

# Train ML model to predict best time slots
def train_ml_model():
    df = load_past_appointments()

    # Convert categorical time values into numerical features
    df["hour"] = df["start_time"].apply(lambda x: int(x.split(":")[0]))
    df["day_num"] = df["day_of_week"].map({"Monday": 0, "Tuesday": 1, "Wednesday": 2, "Thursday": 3, "Friday": 4})

    # Label encoding for status
    label_encoder = LabelEncoder()
    df["status_encoded"] = label_encoder.fit_transform(df["status"])  # 0 = available, 1 = booked

    # Features (X) and Target (y)
    X = df[["hour", "day_num"]]
    y = df["status_encoded"]

    # Train a simple ML model
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X, y)

    return model

# ML Model Initialization
ml_model = train_ml_model()

@app.route('/get_smart_slots', methods=['GET'])
def get_smart_slots():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Fetch available slots from the database
    cursor.execute("SELECT date, start_time, end_time FROM availability WHERE status = 'available'")
    slots = cursor.fetchall()
    conn.close()

    if not slots:
        return jsonify({"error": "No available slots"}), 500

    # Convert available slots into feature format
    suggested_slots = []
    for slot in slots:
        slot_date = slot['date'].strftime("%Y-%m-%d")
        start_time = slot['start_time']
        day_of_week = datetime.strptime(slot_date, "%Y-%m-%d").strftime("%A")  # Get weekday

        # Convert time and day into model input
        hour = int(str(start_time).split(":")[0])
        day_num = {"Monday": 0, "Tuesday": 1, "Wednesday": 2, "Thursday": 3, "Friday": 4}.get(day_of_week, -1)

        # ML Prediction (0 = available, 1 = booked)
        if ml_model.predict([[hour, day_num]])[0] == 0:
            suggested_slots.append({
                "date": slot_date,
                "start_time": str(start_time),
                "end_time": str(slot['end_time'])
            })

    return jsonify({"suggested_slots": suggested_slots})

if __name__ == '__main__':
    app.run(debug=True)